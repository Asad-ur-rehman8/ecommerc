import React from "react";
function Nav(prop) {
    return(

        
        <nav class="navbar navbar-expand-lg">
        <div class="container-xl">
            <a class="navbar-brand me-lg-5 " href="#">
                <img src={prop.logjpg} width="100px" alt="logo"/>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav gap-lg-4 ">
                    <li class="nav-item"> 
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./about.html">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./products.html">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./contact.html">Contact Us</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>



    
)
}

export default Nav 