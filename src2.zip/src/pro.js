import React from "react"
function My(){
    return(


<section>
<div class="container-xl">
    <div class="d-flex flex-column justify-content-center align-items-start mb-3">
        <span class="badge text-start" style="color: var(--primary);">TASHA</span>
        <h3 class="h1"><strong>Our <span style="color: var(--primary);">Featured Products</span></strong>
        </h3>
        <img src="https://media.istockphoto.com/id/1190388161/photo/confectioner-girl-is-preparing-a-cake-concept-ingredients-for-cooking-flour-products-or.jpg?s=612x612&w=0&k=20&c=nhStdu2T88ZAfS8X6wTPQMi_w77S25p95FRWmUecaGc=" width="120px"height="120px" alt=""/>
    </div>
    <div class="row row-cols-1 row-cols-sm-2">
        <div class="col mb-4 d-flex justify-content-center  ">
            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                <div class="row g-0 h-100">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
                            <img src="./images/categories/appliances/a_food_chopper.avif"
                                class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>
                                <h5 class="card-title fw-bold mb-1">Food Choppers</h5>
                                <p class="card-text mb-1">A food chopper is a compact appliance or manually
                                    operated kitchen tool</p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style="color: var(--primary);">Rs: 2400</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 d-flex justify-content-center ">
            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                <div class="row g-0 h-100">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
                            <img src="https://media.istockphoto.com/id/1190388161/photo/confectioner-girl-is-preparing-a-cake-concept-ingredients-for-cooking-flour-products-or.jpg?s=612x612&w=0&k=20&c=nhStdu2T88ZAfS8X6wTPQMi_w77S25p95FRWmUecaGc="
                                class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>
                                <h5 class="card-title fw-bold mb-1">Cooking Pot</h5>
                                <p class="card-text mb-1">A container of earthenware, metal,etc., </p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style="color: var(--primary);">Rs: 2400</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 d-flex justify-content-center ">
            <div class="card rounded-4 overflow-hidden shadow h-100">
                <div class="row g-0 h-100 w-100 ">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
                            <img src="https://media.istockphoto.com/id/1190388161/photo/confectioner-girl-is-preparing-a-cake-concept-ingredients-for-cooking-flour-products-or.jpg?s=612x612&w=0&k=20&c=nhStdu2T88ZAfS8X6wTPQMi_w77S25p95FRWmUecaGc="
                                class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>

                                <h5 class="card-title fw-bold mb-1">Freezer</h5>
                                <p class="card-text mb-1">A freezer is a large container like a fridge in which
                                    the temperature is kept below </p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style="color: var(--primary);">Rs: 2400</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 d-flex justify-content-center ">
            <div class="card rounded-4 overflow-hidden shadow h-100">
                <div class="row g-0 h-100 w-100 ">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
                            <img src="https://media.istockphoto.com/id/1190388161/photo/confectioner-girl-is-preparing-a-cake-concept-ingredients-for-cooking-flour-products-or.jpg?s=612x612&w=0&k=20&c=nhStdu2T88ZAfS8X6wTPQMi_w77S25p95FRWmUecaGc="
                                class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>

                                <h5 class="card-title fw-bold mb-1">Vacuum Bottles</h5>
                                <p class="card-text mb-1">A vacuum bottle (also known as a Dewar flask, Dewar
                                    bottle or
                                    thermos) is an insulating storage vessel </p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style="color: var(--primary);">Rs: 2400</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>

)
}
export default My