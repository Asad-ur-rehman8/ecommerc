import React from "react";
import  pic1 from "./images/clientImages/01.png"
import pic3 from "./images/clientImages/03.png"
import pic2 from "./images/clientImages/03.png"
import { Link} from 'react-router-dom';
function About(prop){
    const customStyle = {
        color: "var(--primary)"
    }
    const customStyle2 = {
        border:0
    }
const customstyle3 = {
        border: " 2px solid var(--primary)"
    }

    return(
        <div>


        <nav class="navbar navbar-expand-lg">
        <div class="container-xl">
                <a class="navbar-brand me-lg-5 " href="#">        
                <img src={prop.logjpg} width="100px" alt="logo"/>      
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                    aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav gap-lg-4 ">
                        <li class="nav-item">
                            <Link class="nav-link" aria-current="page" to="/">Home</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/about">About</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/product">Products</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link active" to="/Contact__us">Contact Us</Link>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    









        <div class="container-xl">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex flex-column justify-content-center mt-5 align-items-start mb-3">                
                <span class="badge text-start" style={customStyle}>TASHA</span>
                    <h3 class="h1"><strong>Know <span style={customStyle}>About Us</span></strong>
               </h3>     
               <img src={prop.mask} width="120px" alt=""/>
            </div>
             <p>Welcome to Kitchen-Appliances, your trusted source for high-quality kitchen appliances that make
                    cooking a breeze. At Kitchen-Appliances, we're more than just a retailer; we're your kitchen
                    companion, dedicated to simplifying your culinary journey.</p>

                <div class="d-flex flex-column justify-content-center mt-5 align-items-start mb-3">
                    <span class="badge text-start" style={customStyle}>TASHA</span>
                    <h3 class="h1"><strong>Our <span style={customStyle}>Commitment</span></strong>
                    </h3>
          <img src={prop.mask} width="120px" alt=""/>
                           </div>
                                    <p>At Kitchen-Appliances, our commitment to excellence is unwavering. We're driven by the following core
                    values:</p>
                <ul>
                    <li>
          <span class="fw-bold" style={customStyle}>Quality:</span> We never compromise on
                              quality. Every product we offer
                        undergoes rigorous testing to ensure it meets our high standards.
                    </li>
                    <li>
                   <span class="fw-bold" style={customStyle}>Innovation:</span> We're constantly pushing       
                        the boundaries of kitchen
                        technology. Our team of experts is dedicated to developing appliances that make your life easier
                        and more enjoyable.
                    </li>
                    <li>
                                      <span class="fw-bold" style={customStyle}>Customer Satisfaction:</span> Your
                    satisfaction is our priority. We're
                        here to support you every step of the way, from choosing the right appliance to providing
                        top-notch customer service.
                    </li>
                </ul>
                <div class="container my-3">
                    <div class="d-flex flex-column justify-content-center mt-5 align-items-md-center mb-3">
                                    <span class="badge text-start" style={customStyle}>TASHA</span>
                        <h3 class="h1"><strong>What Our <br class="d-block d-md-none "/><span
                        style={customStyle}>Customers say!</span></strong>
                        </h3>
                        <img src={prop.mask} width="120px" alt=""/>
                      </div>
                    <div class="row">       
                        <div class="col-md-4">
                            <div class="testimonial-card">
                            <img src={pic1} alt="Customer 1" class="testimonial-avatar"/>
                               <h4 class="fw-bold " style={customStyle}>Muzammil</h4>                  
                                             <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor libero quis
                                    tincidunt."
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="testimonial-card">
                                           <img src={pic2} alt="Customer 2" class="testimonial-avatar"/>
                             <h4 class="fw-bold " style={customStyle}>Abdul Kareem</h4>
                        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor libero quis
                                    tincidunt."
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="testimonial-card">
                        <img src={pic3} alt="Customer 3" class="testimonial-avatar"/>
                                <h4 class="fw-bold " style={customStyle}>Ayan</h4>
                                <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor libero quis
                                    tincidunt."
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container my-3 mb-5 ">
                    <div class="d-flex flex-column justify-content-center mt-5 align-items-md-center mb-3">
                        <span class="badge text-start" style={customStyle}>TASHA</span>
                        <h3 class="h1"><strong>Get <span style={customStyle}>in Touch!</span></strong>
                        </h3>
                    <img src={prop.mask} width="120px" alt=""/>
                    </div>
                    <p class="text-center mt-1">We'd love to hear from you! If you have any questions, feedback, or need
                        assistance,
                        please don't hesitate to contact us:</p>
                    <div class="row">
                            <div class="col-md-4">
                            <div class="contact-card">
                        <i class="bi bi-telephone fs-1  " style={customStyle}></i>
                             <h4 class="fw-bold " style={customStyle}>Phone</h4>     
                                <p>0300-1234567</p>
                            </div>
                        </div>
                               <div class="col-md-4">
                            <div class="contact-card">
                 <i class="bi bi-envelope fs-1 " style={customStyle}></i>
                        <h4 class="fw-bold " style={customStyle}>Email</h4>
                                            <p>Abc@example.com</p>
                            </div>
                        </div>
            <div class="col-md-4">
                            <div class="contact-card">
                        <i class="bi bi-geo-alt fs-1  " style={customStyle}></i>
                    <h4 class="fw-bold " style={customStyle}>Address</h4>
                                <p>123 Street, Karachi, Pakistan</p>
                            </div>
                        </div>
                 <div class="social-media-links text-center">
                            <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
                            <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            <a href="#" target="_blank"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>
                <div class="d-flex flex-column justify-content-center mt-5 align-items-start mb-3">
                <span class="badge text-start" style={customStyle}>TASHA</span>
            <h3 class="h1"><strong>Our <span style={customStyle}>Range</span></strong>
                    </h3>
                    <img src={prop.mask} width="120px" alt=""/>
                        </div>
                          <p>Explore our wide range of kitchen appliances, carefully curated to cater to your culinary needs.
                    Whether you're a seasoned chef or a novice cook, we have something for everyone:</p>
                <ul>
                    <li>
                        <span class="fw-bold ">Cooking Appliances:</span> From state-of-the-art ovens to versatile
                        cooktops, we have the tools to bring your culinary creations to life.
                    </li>
                    <li>
                        <span class="fw-bold ">Kitchen Essentials:</span> Discover a range of must-have kitchen gadgets
                        and accessories that will simplify your meal preparation.
                    </li>
                </ul>
            </div>
        </div>
    </div>
       <p class="text-center mb-5 ">Thank you for choosing Kitchen-Appliances as your kitchen companion. We look forward to
        serving you and helping
        you create culinary magic in your home.</p>
            <footer class="bg-dark text-white py-5 rounded-top-5  ">
        <div class="container-xl">
            <div class="row">
                <div class="col-md-2 mb-5">
                        <img src={ prop.logjpg2} width="100%" alt=""/>
                        </div>
                <div class="col-md-5 mb-5">
                    <div class="d-flex justify-content-around ">
                        <div>
                            <h3 class="h4" style={customStyle}>Links</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><Link to="/" class="text-white">Home</Link></li>
                                <li class="mb-3"><Link to="/about" class="text-white">About</Link></li>
                                <li class="mb-3"><Link to="/Contact__us" class="text-white active">Contact</Link></li>
                            </ul>
                        </div>
                        <div>
                            <h3 class="h4" style={customStyle}>Categories</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><a href="#" class="text-white">Cookwares</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Refrigerators</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Appliances</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Food Storage</a></li>
                            </ul>

                        </div>
                    </div>
                </div>
                <div class="col-md-5 mb-5">
                    <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style={customStyle}>in Touch</span>
                    </h4>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-envelope fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">info@tasha.com</span>
                        </div>
                    </div>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-telephone fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">0300-0000000</span>
                        </div>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
                                style={customStyle}>Address</span></h4>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
                            width="100%" style={customStyle2} allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style={customStyle}>Social
                                Accounts</span></h4>
                        <div class="d-flex justify-content-around social">
                            <i class="bi bi-facebook fs-3"></i>
                            <i class="bi bi-whatsapp fs-3"></i>
                            <i class="bi bi-instagram fs-3"></i>
                            <i class="bi bi-twitter fs-3"></i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </footer>
            </div>
    )
}
export default About