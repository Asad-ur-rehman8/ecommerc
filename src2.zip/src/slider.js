import React from "react";
//import "./stylee.css"
function Slid(prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    return(

      <section class="py-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div id="homeCarousel" class="carousel slide w-100 " data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="container-fluid">
                                    <div class="row">
                                        <div
                                            class="col-md-6 d-flex flex-column  align-items-center justify-content-center ">
                                            <div class="d-flex flex-column justify-content-center hero-content">
                                            <span class="badge text-start "
                                            style={customStyle}>TASHA</span>
                                                  <h3 class="h1"><strong>Make your kitchen</strong> <br/> look
                                                    awesome</h3>
                                                <p class="fs-6 ">Lorem ipsum dolor sit amet consectetur adipisicing
                                                    elit.
                                                    Temporibus labore
                                                    eveniet, amet
                                                    doloribus suscipit autem rem placeat officiis </p>
                                            </div>
                                        </div>
                                        <div class="col-md-6 carousel-image-container">
                                            <img src={prop.log} class="d-block w-100 rounded-5 "
                                                alt="01"/>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="container-fluid">
                                    <div class="row">

                                        <div
                                            class="col-md-6 d-flex flex-column  align-items-center justify-content-center ">

                                            <div class="d-flex flex-column justify-content-center hero-content">
                                                <span class="badge text-start "
              
              
                                                style={customStyle}>TASHA</span>
                                       
                                       
                                       
                                                <h3 class="h1"><strong>Make your kitchen</strong> <br/> look
                                                 awesome</h3>
                                                <p class="fs-6 ">Lorem ipsum dolor sit amet consectetur adipisicing
                                                    elit.
                                                    Temporibus labore
                                                    eveniet, amet
                                                    doloribus suscipit autem rem placeat officiis </p>
                                            </div>

                                        </div>
                                        <div class="col-md-6 carousel-image-container">
                                            <img src={prop.secimg} class="d-block w-100 rounded-5 "
                                                alt="01"/>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="container-fluid">
                                    <div class="row">

                                        <div
                                            class="col-md-6 d-flex flex-column  align-items-center justify-content-center ">

                                            <div class="d-flex flex-column justify-content-center hero-content">
                                                <span class="badge text-start "
              
              
              
              
              
                                                style={customStyle}>TASHA</span>
              
              
              
              
              
                                                    <h3 class="h1"><strong>Make your kitchen</strong> <br/> look
                                                    awesome</h3>
                                                <p class="fs-6 ">Lorem ipsum dolor sit amet consectetur adipisicing
                                                    elit.
                                                    Temporibus labore
                                                    eveniet, amet
                                                    doloribus suscipit autem rem placeat officiis </p>
                                            </div>

                                        </div>
                                        <div class="col-md-6 carousel-image-container">
                                            <img src={prop.five} class="d-block w-100 rounded-5 "
                                                alt="01"/>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-12 col-md-6">
                                    <div class="d-flex justify-content-center gap-5 mt-md-0 mt-3">
                                        <button class="border-0 bg-transparent text-dark " type="button"
                                            data-bs-target="#homeCarousel" data-bs-slide="prev">
                                            <i class="bi bi-chevron-double-left fs-3 "></i>
                                        </button>
                                        <button class="border-0 bg-transparent text-dark " type="button"
                                            data-bs-target="#homeCarousel" data-bs-slide="next">
                                            <i class="bi bi-chevron-double-right fs-3 "></i>
                                        </button>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>






    )
}
export default Slid