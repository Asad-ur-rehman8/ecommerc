import React from "react"

function  Food_storage(prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    return(
<>
<section>        
         <div class="mb-5 ">
             <div class="heading-bottom-line my-3 d-flex justify-content-between ">
                 <h3 class="h3 fw-bold  py-1 m-0 ">Food Storage</h3>
                 <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                             class="bi bi-arrow-right-circle"></i></button></a>
             </div>
             <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4   ">
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore}
                                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Spice Jars</h5>
                                 <p class="card-text mb-1">These jars are ideal for storing all your herbs, spices, tea bags, and lentils.</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore2}
                                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Lunch Boxes</h5>
                                 <p class="card-text mb-1">For the consumers, stainless steel has been the most preferred type of lunch box</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore3}
                                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Storage Bags</h5>
                                 <p class="card-text mb-1">Similar to LDPE bags, LLDPE bags can be used for storing food in both refrigerators and freezers</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore4}     class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Flask</h5>
                                 <p class="card-text mb-1">Vacuum flasks are used domestically to keep beverages hot or cold for extended periods</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                         </div>
                 </div>
             </div>
         </div>
     </section>
 
     </>
           
    )
}
export default Food_storage