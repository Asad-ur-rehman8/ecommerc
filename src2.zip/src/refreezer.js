import React from "react";
function Freezer(prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    return(
        
        <div class="mb-5 ">
        <div class="heading-bottom-line my-3 d-flex justify-content-between ">
            <h3 class="h3 fw-bold  py-1 m-0 ">Refrigerators</h3>
            <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                        class="bi bi-arrow-right-circle"></i></button></a>
        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4   ">
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">


                    <img src={prop.fre2}


                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Freezer</h5>
                            <p class="card-text mb-1">A freezer is a large container like a fridge in which the
                                temperature is kept below freezing point</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                               <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">


                    <img src={prop.fre3}



                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Refrigerator Mini</h5>
                            <p class="card-text mb-1">A refrigerator is a machine for keeping things cold.It is
                                sometimes called an fridge.</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span> 
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">


                    <img src={prop.fre4}


                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Freezer Black</h5>
                            <p class="card-text mb-1">A freezer is a large container like a fridge in which the
                                temperature is kept below freezing point</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">


                    <img src={prop.d}


                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Refrigerator with double door</h5>
                            <p class="card-text mb-1">A refrigerator is a machine for keeping things cold.It is
                                sometimes called an fridge.</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    )
}
export default Freezer