import React from "react"

function Cookware(prop) {
    const customStyle = {
        color: "var(--primary)"
    }    

return(
 <>
 <div class="container-xl">
 <div class="d-flex flex-column justify-content-center mt-5 align-items-md-center mb-5">
            <span class="badge text-start" style={customStyle}>TASHA</span>
            <h3 class="h1"><strong>What we <span style={customStyle}> Have for You</span></strong>
            </h3>
            <img src={prop.mask}width={"120px"} alt=""/>
      </div>
 </div>
     <div class="mb-5 ">
<div class="heading-bottom-line my-3 d-flex justify-content-between ">
    <h3 class="h3 fw-bold  py-1 m-0 ">Cookwares</h3>
    <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                class="bi bi-arrow-right-circle"></i></button></a>
</div>
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4">
    <div class="col mb-4 d-flex justify-content-center  ">
        <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
            <div class="ratio ratio-16x9 h-100 ">
          
            <img src={prop.imc2}
          
            class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
            </div>
            <div class="card-body d-flex flex-column justify-content-between h-100">
                <div>
                    <h5 class="card-title fw-bold mb-1">Cooking Pan</h5>
                    <p class="card-text mb-1">Cooking pans typically have one long handle and are more
                        shallow than pots.</p>
                </div>
                <div>
                    <div class="rating fs-6 ">
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-faill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star"></span>
                    </div>
                    <div class="price d-flex justify-content-end fs-4">
                        <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col mb-4 d-flex justify-content-center  ">
        <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
            <div class="ratio ratio-16x9 h-100 ">
          
            <img src={prop.imc3}
          
          
            class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
            </div>
            <div class="card-body d-flex flex-column justify-content-between h-100">
                <div>
                    <h5 class="card-title fw-bold mb-1">Cookware Set</h5>
                    <p class="card-text mb-1">A kitchen utensil is a small hand held tool used for food
                        preparation.</p>
                </div>
                <div>
                    <div class="rating fs-6 ">
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star"></span>
                    </div>
                    <div class="price d-flex justify-content-end fs-4">
                        <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col mb-4 d-flex justify-content-center  ">
        <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
            <div class="ratio ratio-16x9 h-100 ">
          
            <img src={prop.imc4}
          
            
            class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
            </div>
            <div class="card-body d-flex flex-column justify-content-between h-100">
                <div>
                    <h5 class="card-title fw-bold mb-1">Grill Pen</h5>
                    <p class="card-text mb-1">A griLL pan is a kind of frying pan with a ribbed surface
                    to let the fat drain from food.</p>
                </div>
                <div>
                    <div class="rating fs-6 ">
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star-fill"></span>
                        <span class="bi bi-star"></span>
                    </div>
                    <div class="price d-flex justify-content-end fs-4">
                        <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col mb-4 d-flex justify-content-center  ">
        <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
            <div class="ratio ratio-16x9 h-100 ">
          
            <img src={prop.fre1}
          
          
            class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
            </div>
            <div class="card-body d-flex flex-column justify-content-between h-100">
                <div>
                    <h5 class="card-title fw-bold mb-1">Steamer</h5>
                    <p class="card-text mb-1">A food steamer or steam cooker is a small kitchen
                        appliance used to cook or prepare various foods</p>
                </div>
                <div>
                <div class="rating fs-6 ">
                <span class="bi bi-star-fill"></span>
                <span class="bi bi-star-fill"></span>
                <span class="bi bi-star-fill"></span>
                <span class="bi bi-star-fill"></span>
                <span class="bi bi-star"></span>
                </div>
                <div class="price d-flex justify-content-end fs-4">
                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


</>
)
}
export default Cookware