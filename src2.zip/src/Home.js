import React from "react";
import { Link} from 'react-router-dom';
function  Home(prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    const cus={

        border :"0"
    }
    return(
        <div>
    <nav class="navbar navbar-expand-lg">
    <div class="container-xl">
        <a class="navbar-brand me-lg-5 " href="#">
            <img src={prop.logjpg} width="100px" alt="logo"/>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav gap-lg-4 ">
                <li class="nav-item"> 
                    <Link class="nav-link active" aria-current="page" to="/">Home</Link>
                </li>
                <li class="nav-item">
                    <Link class="nav-link" to="/about">About</Link>
                </li>
                <li class="nav-item">
                    <Link class="nav-link" to="/product">Products</Link>
                </li>
                <li class="nav-item">
                    <Link class="nav-link" to="/Contact__us">Contact Us</Link>
                </li>
            </ul>
        </div>
    </div>
</nav>




<section class="py-5">
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div id="homeCarousel" class="carousel slide w-100 " data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="container-fluid">
                            <div class="row">
                                <div
                                    class="col-md-6 d-flex flex-column  align-items-center justify-content-center ">
                                    <div class="d-flex flex-column justify-content-center hero-content">
                                    <span class="badge text-start "
                                    style={customStyle}>TASHA</span>
                                          <h3 class="h1"><strong>Make your kitchen</strong> <br/> look
                                            awesome</h3>
                                        <p class="fs-6 ">Lorem ipsum dolor sit amet consectetur adipisicing
                                            elit.
                                            Temporibus labore
                                            eveniet, amet
                                            doloribus suscipit autem rem placeat officiis </p>
                                    </div>
                                </div>
                                <div class="col-md-6 carousel-image-container">
                                    <img src={prop.log} class="d-block w-100 rounded-5 "
                                        alt="01"/>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="container-fluid">
                            <div class="row">

                                <div
                                    class="col-md-6 d-flex flex-column  align-items-center justify-content-center ">

                                    <div class="d-flex flex-column justify-content-center hero-content">
                                        <span class="badge text-start "
      
      
                                        style={customStyle}>TASHA</span>
                               
                               
                               
                                        <h3 class="h1"><strong>Make your kitchen</strong> <br/> look
                                         awesome</h3>
                                        <p class="fs-6 ">Lorem ipsum dolor sit amet consectetur adipisicing
                                            elit.
                                            Temporibus labore
                                            eveniet, amet
                                            doloribus suscipit autem rem placeat officiis </p>
                                    </div>

                                </div>
                                <div class="col-md-6 carousel-image-container">
                                    <img src={prop.secimg} class="d-block w-100 rounded-5 "
                                        alt="01"/>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="container-fluid">
                            <div class="row">

                                <div
                                    class="col-md-6 d-flex flex-column  align-items-center justify-content-center ">

                                    <div class="d-flex flex-column justify-content-center hero-content">
                                        <span class="badge text-start "
      
      
      
      
      
                                        style={customStyle}>TASHA</span>
      
      
      
      
      
                                            <h3 class="h1"><strong>Make your kitchen</strong> <br/> look
                                            awesome</h3>
                                        <p class="fs-6 ">Lorem ipsum dolor sit amet consectetur adipisicing
                                            elit.
                                            Temporibus labore
                                            eveniet, amet
                                            doloribus suscipit autem rem placeat officiis </p>
                                    </div>

                                </div>
                                <div class="col-md-6 carousel-image-container">
                                    <img src={prop.five} class="d-block w-100 rounded-5 "
                                        alt="01"/>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="d-flex justify-content-center gap-5 mt-md-0 mt-3">
                                <button class="border-0 bg-transparent text-dark " type="button"
                                    data-bs-target="#homeCarousel" data-bs-slide="prev">
                                    <i class="bi bi-chevron-double-left fs-3 "></i>
                                </button>
                                <button class="border-0 bg-transparent text-dark " type="button"
                                    data-bs-target="#homeCarousel" data-bs-slide="next">
                                    <i class="bi bi-chevron-double-right fs-3 "></i>
                                </button>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
</section>




<section>
<div class="container-xl">
    <div class="d-flex flex-column justify-content-center align-items-start mb-3"></div>
        <span class="badge text-start" style={customStyle}>TASHA</span>
        <h3 class="h1"><strong>Our <span style={customStyle}>Featured Products</span></strong>
        </h3>
        
        
        <img src={prop.mask} width="120px" alt=""/>
    
    
        </div>
    <div class="row row-cols-1 row-cols-sm-2">
        <div class="col mb-4 d-flex justify-content-center  ">
            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                <div class="row g-0 h-100">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
    
    
                       <img src={prop.chopper}
    
    
                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>
                                <h5 class="card-title fw-bold mb-1">Food Choppers</h5>
                                <p class="card-text mb-1">A food chopper is a compact appliance or manually
                                    operated kitchen tool</p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 d-flex justify-content-center ">
            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                <div class="row g-0 h-100">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
    
    
    
                        <img src={prop.pot}       
    
    
    
                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>
                                <h5 class="card-title fw-bold mb-1">Cooking Pot</h5>
                                <p class="card-text mb-1">A container of earthenware, metal,etc., </p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 d-flex justify-content-center ">
            <div class="card rounded-4 overflow-hidden shadow h-100">
                <div class="row g-0 h-100 w-100 ">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
                    
                    
                    
                    
                        <img src={prop.freez}
    


                            
                            class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>

                                <h5 class="card-title fw-bold mb-1">Freezer</h5>
                                <p class="card-text mb-1">A freezer is a large container like a fridge in which
                                    the temperature is kept below </p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col mb-4 d-flex justify-content-center ">
            <div class="card rounded-4 overflow-hidden shadow h-100">
                <div class="row g-0 h-100 w-100 ">
                    <div class="col-md-6">
                        <div class="ratio ratio-4x3 h-100 ">
                    
                    
                    
                    
                        <img src={prop.vac}
                    
                    
                    
                    
                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body d-flex flex-column justify-content-between h-100">
                            <div>

                                <h5 class="card-title fw-bold mb-1">Vacuum Bottles</h5>
                                <p class="card-text mb-1">A vacuum bottle (also known as a Dewar flask, Dewar
                                    bottle or
                                    thermos) is an insulating storage vessel </p>
                            </div>
                            <div>
                                <div class="rating fs-6 ">
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star-fill"></span>
                                    <span class="bi bi-star"></span>
                                </div>
                                <div class="price d-flex justify-content-end fs-4">
                                    <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>




<section clasNamesName="my-5 ">
<div className="container-fluid">
          <div className="row">
              <div className="col-12">
                  <div id="banner" className="carousel slide carousel-fade" data-bs-ride="carousel">
                      <div className="carousel-inner">
                          <div className="carousel-item active">
                              <img src={prop.ig} class="d-block w-100 img-fluid " alt="01"/>
                          </div>
                          <div className="carousel-item">
                              <img src={prop.fimage} class="d-block w-100 img-fluid " alt="02"/>
                          </div>
                          <div className="carousel-item">
                              <img src={prop.trd} class="d-block w-100 img-fluid " alt="03"/>
                          </div>
                      </div>
                      <button className="carousel-control-prev" type="button" data-bs-target="#banner"
                          data-bs-slide="prev">
                          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                      </button>
                      <button className="carousel-control-next" type="button" data-bs-target="#banner"
                          data-bs-slide="next">
                          <span className="carousel-control-next-icon" aria-hidden="true"></span>
                      </button>
                  </div>
              </div>
          </div>
      </div>
  </section>


  <div class="container-xl">
  <div class="d-flex flex-column justify-content-center mt-5 align-items-md-center mb-5">
             <span class="badge text-start" style={customStyle}>TASHA</span>
             <h3 class="h1"><strong>What we <span style={customStyle}> Have for You</span></strong>
             </h3>
             <img src={prop.mask}width={"120px"} alt=""/>
       </div>
  </div>
      <div class="mb-5 ">
 <div class="heading-bottom-line my-3 d-flex justify-content-between ">
     <h3 class="h3 fw-bold  py-1 m-0 ">Cookwares</h3>
     <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                 class="bi bi-arrow-right-circle"></i></button></a>
 </div>
 <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4">
     <div class="col mb-4 d-flex justify-content-center  ">
         <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
             <div class="ratio ratio-16x9 h-100 ">
           
             <img src={prop.imc2}
           
             class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
             </div>
             <div class="card-body d-flex flex-column justify-content-between h-100">
                 <div>
                     <h5 class="card-title fw-bold mb-1">Cooking Pan</h5>
                     <p class="card-text mb-1">Cooking pans typically have one long handle and are more
                         shallow than pots.</p>
                 </div>
                 <div>
                     <div class="rating fs-6 ">
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-faill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star"></span>
                     </div>
                     <div class="price d-flex justify-content-end fs-4">
                         <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <div class="col mb-4 d-flex justify-content-center  ">
         <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
             <div class="ratio ratio-16x9 h-100 ">
              <img src={prop.imc3}          
             class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
             </div>
             <div class="card-body d-flex flex-column justify-content-between h-100">
                 <div>
                     <h5 class="card-title fw-bold mb-1">Cookware Set</h5>
                     <p class="card-text mb-1">A kitchen utensil is a small hand held tool used for food
                         preparation.</p>
                 </div>
                 <div>
                     <div class="rating fs-6 ">
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star"></span>
                     </div>
                     <div class="price d-flex justify-content-end fs-4">
                         <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <div class="col mb-4 d-flex justify-content-center  ">
         <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
             <div class="ratio ratio-16x9 h-100 ">
             <img src={prop.imc4}           
             class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
             </div>
             <div class="card-body d-flex flex-column justify-content-between h-100">
                 <div>
                     <h5 class="card-title fw-bold mb-1">Grill Pen</h5>
                     <p class="card-text mb-1">A griLL pan is a kind of frying pan with a ribbed surface
                     to let the fat drain from food.</p>
                 </div>
                 <div>
                     <div class="rating fs-6 ">
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star-fill"></span>
                         <span class="bi bi-star"></span>
                     </div>
                     <div class="price d-flex justify-content-end fs-4">
                         <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <div class="col mb-4 d-flex justify-content-center  ">
         <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
             <div class="ratio ratio-16x9 h-100 ">
              <img src={prop.fre1}         
             class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
             </div>
             <div class="card-body d-flex flex-column justify-content-between h-100">
                 <div>
                     <h5 class="card-title fw-bold mb-1">Steamer</h5>
                     <p class="card-text mb-1">A food steamer or steam cooker is a small kitchen
                         appliance used to cook or prepare various foods</p>
                 </div>
                 <div>
                 <div class="rating fs-6 ">
                 <span class="bi bi-star-fill"></span>
                 <span class="bi bi-star-fill"></span>
                 <span class="bi bi-star-fill"></span>
                 <span class="bi bi-star-fill"></span>
                 <span class="bi bi-star"></span>
                 </div>
                 <div class="price d-flex justify-content-end fs-4">
                 <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                 </div>
                 </div>
             </div>
         </div>
     </div>
     </div>
     </div>
     <div class="mb-5 ">
     <div class="heading-bottom-line my-3 d-flex justify-content-between ">
         <h3 class="h3 fw-bold  py-1 m-0 ">Appliances</h3>
         <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                     class="bi bi-arrow-right-circle"></i></button></a>
     </div>
     <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4   ">
         <div class="col mb-4 d-flex justify-content-center  ">
             <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                 <div class="ratio ratio-16x9 h-100 ">
                  <img src={prop.applin2}
                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                 </div>
                 <div class="card-body d-flex flex-column justify-content-between h-100">
                     <div>
                         <h5 class="card-title fw-bold mb-1">Food Choppers</h5>
                         <p class="card-text mb-1">A food chopper is a compact appliance or manually
                             operated kitchen tool</p>
                     </div>
                     <div>
                         <div class="rating fs-6 ">
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star"></span>
                         </div>
                         <div class="price d-flex justify-content-end fs-4">
                             <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <div class="col mb-4 d-flex justify-content-center  ">
             <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                 <div class="ratio ratio-16x9 h-100 ">
             <img src={prop.applin3}               
                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                 </div>
                 <div class="card-body d-flex flex-column justify-content-between h-100">
                     <div>
                         <h5 class="card-title fw-bold mb-1">Electric kettle</h5>
                         <p class="card-text mb-1">An electric kettle plugs into an outlet and uses
                             electricity to power an integrated heating element</p>
                     </div>
                     <div>
                         <div class="rating fs-6 ">
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star"></span>
                         </div>
                         <div class="price d-flex justify-content-end fs-4">
                             <span class="bi bi-star"></span> 
                             <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                         </div>
                         
                     </div>
                 </div>
             </div>
         </div>
         <div class="col mb-4 d-flex justify-content-center  ">
             <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                 <div class="ratio ratio-16x9 h-100 ">
                    <img src={prop.applin4}               
                   class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                 </div>
                 <div class="card-body d-flex flex-column justify-content-between h-100">
                     <div>
                         <h5 class="card-title fw-bold mb-1">Bread Maker</h5>
                         <p class="card-text mb-1">Bread makers are kitchen appliances used to make bread.
                         </p>
                     </div>
                     <div>
                         <div class="rating fs-6 ">
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star"></span>
                         </div>
                         <div class="price d-flex justify-content-end fs-4">
                             <span class="bi bi-star"></span>
                             <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
         <div class="col mb-4 d-flex justify-content-center  ">
             <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                 <div class="ratio ratio-16x9 h-100 ">
                <img src={prop.applin1}      
                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                     <div>
                         <h5 class="card-title fw-bold mb-1">Toaster</h5>
                         <p class="card-text mb-1">A toaster is a kitchen appliance for toasting food such as
                             sliced bread, crumpets, and bagels</p>
                     </div>
                     <div>
                         <div class="rating fs-6 ">
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star-fill"></span>
                             <span class="bi bi-star"></span>
                         </div>
                         <div class="price d-flex justify-content-end fs-4">
                             <span class="bi bi-star"></span>
                             <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>

 <section>        
         <div class="mb-5 ">
             <div class="heading-bottom-line my-3 d-flex justify-content-between ">
                 <h3 class="h3 fw-bold  py-1 m-0 ">Food Storage</h3>
                 <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                             class="bi bi-arrow-right-circle"></i></button></a>
             </div>
             <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4   ">
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore}
                                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Spice Jars</h5>
                                 <p class="card-text mb-1">These jars are ideal for storing all your herbs, spices, tea bags, and lentils.</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore2}
                                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Lunch Boxes</h5>
                                 <p class="card-text mb-1">For the consumers, stainless steel has been the most preferred type of lunch box</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore3}
                                 class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Storage Bags</h5>
                                 <p class="card-text mb-1">Similar to LDPE bags, LLDPE bags can be used for storing food in both refrigerators and freezers</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="col mb-4 d-flex justify-content-center  ">
                     <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                         <div class="ratio ratio-16x9 h-100 ">
                             <img src={prop.fdstore4}     class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                         </div>
                         <div class="card-body d-flex flex-column justify-content-between h-100">
                             <div>
                                 <h5 class="card-title fw-bold mb-1">Flask</h5>
                                 <p class="card-text mb-1">Vacuum flasks are used domestically to keep beverages hot or cold for extended periods</p>
                             </div>
                             <div>
                                 <div class="rating fs-6 ">
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star-fill"></span>
                                     <span class="bi bi-star"></span>
                                 </div>
                                 <div class="price d-flex justify-content-end fs-4">
                                     <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                 </div>
                             </div>
                         </div>
                         </div>
                 </div>
             </div>
         </div>
     </section>

     <footer class="bg-dark text-white py-5 rounded-top-5  ">
     <div class="container-xl">
     <div class="row">
                 <div class="col-md-2 mb-5">
                     <img src={prop.logjpg2} width="100%" alt=""/>
                 </div>
                 <div class="col-md-5 mb-5">
                     <div class="d-flex justify-content-around ">
                         <div>
                             <h3 class="h4" style={customStyle}>Links</h3>
                             <ul class="list-unstyled">
                                 <li class="mb-3"><Link to="/" class="text-white active">Home</Link></li>
                                 <li class="mb-3"><Link to="./about" class="text-white">About</Link></li>
                                 <li class="mb-3"><Link to="./Contact__us" class="text-white">Contact</Link></li>
                             </ul>
                         </div>
                         <div>
                             <h3 class="h4" style={customStyle}>Categories</h3>
                             <ul class="list-unstyled">
                                 <li class="mb-3"><a href="#" class="text-white">Cookwares</a></li>
                                 <li class="mb-3"><a href="#" class="text-white">Refrigerators</a></li>
                                 <li class="mb-3"><a href="#" class="text-white">Appliances</a></li>
                                 <li class="mb-3"><a href="#" class="text-white">Food Storage</a></li>
                             </ul>
 
                         </div>
                     </div>
                 </div>
                 <div class="col-md-5 mb-5">
                     <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style={customStyle}>in Touch</span>
                     </h4>
                     <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                         <div class="me-2  ">
                             <i class="bi bi-envelope fs-5" style={customStyle}></i>
                         </div>
                         <div>
                             <span class="fs-5 text-dark">info@tasha.com</span>
                         </div>
                     </div>
                     <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                         <div class="me-2  ">
                             <i class="bi bi-telephone fs-5" style={customStyle}></i>
                         </div>
                         <div>
                             <span class="fs-5 text-dark">0300-0000000</span>
                         </div>
                     </div>
                     <div>
                         <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
                         style={customStyle}>Address</span></h4>
                         <iframe
                             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
                             width="100%" style={cus}allowfullscreen="" loading="lazy"
                             referrerpolicy="no-referrer-when-downgrade"></iframe>
                     </div>
                     <div>
                         <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style={customStyle}>Social
                                 Accounts</span></h4>
                         <div class="d-flex justify-content-around social">
                             <i class="bi bi-facebook fs-3"></i>
                             <i class="bi bi-whatsapp fs-3"></i>
                             <i class="bi bi-instagram fs-3"></i>
                             <i class="bi bi-twitter fs-3"></i>
                         </div>
                     </div>
 
                 </div>
             </div>
         </div>
     </footer>
    </div>
)  
}
export default Home