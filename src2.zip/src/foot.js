import React from "react"
import logo from './logo.svg'
//import "./style.css"
function FOOOter (prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    const cus={

        border :"0"
    }
    return(
      
        <div>
    <footer class="bg-dark text-white py-5 rounded-top-5  ">
    <div class="container-xl">
    <div class="row">
                <div class="col-md-2 mb-5">
                    <img src={prop.logjpg2} width="100%" alt=""/>
                </div>
                <div class="col-md-5 mb-5">
                    <div class="d-flex justify-content-around ">
                        <div>
                            <h3 class="h4" style={customStyle}>Links</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><a href="#" class="text-white active">Home</a></li>
                                <li class="mb-3"><a href="./about.html" class="text-white">About</a></li>
                                <li class="mb-3"><a href="./contact.html" class="text-white">Contact</a></li>
                            </ul>
                        </div>
                        <div>
                            <h3 class="h4" style={customStyle}>Categories</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><a href="#" class="text-white">Cookwares</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Refrigerators</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Appliances</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Food Storage</a></li>
                            </ul>

                        </div>
                    </div>
                </div>
                <div class="col-md-5 mb-5">
                    <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style={customStyle}>in Touch</span>
                    </h4>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-envelope fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">info@tasha.com</span>
                        </div>
                    </div>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-telephone fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">0300-0000000</span>
                        </div>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
                        style={customStyle}>Address</span></h4>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
                            width="100%" style={cus}allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style={customStyle}>Social
                                Accounts</span></h4>
                        <div class="d-flex justify-content-around social">
                            <i class="bi bi-facebook fs-3"></i>
                            <i class="bi bi-whatsapp fs-3"></i>
                            <i class="bi bi-instagram fs-3"></i>
                            <i class="bi bi-twitter fs-3"></i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </footer>
</div>










    //<h2>asad</h2>
// <footer class="bg-dark text-white py-5 rounded-top-5  ">
// <div class="container-xl">
//     <div class="row">
//         <div class="col-md-2 mb-5">
//             <img src="./images/logos/white.png" width="100%" alt="">
//         </div>
//         <div class="col-md-5 mb-5">
//             <div class="d-flex justify-content-around ">
//                 <div>
//                     <h3 class="h4" style="color: var(--primary);">Links</h3>
//                     <ul class="list-unstyled">
//                         <li class="mb-3"><a href="#" class="text-white active">Home</a></li>
//                         <li class="mb-3"><a href="./about.html" class="text-white">About</a></li>
//                         <li class="mb-3"><a href="./contact.html" class="text-white">Contact</a></li>
//                     </ul>
//                 </div>
//                 <div>
//                     <h3 class="h4" style="color: var(--primary);">Categories</h3>
//                     <ul class="list-unstyled">
//                         <li class="mb-3"><a href="#" class="text-white">Cookwares</a></li>
//                         <li class="mb-3"><a href="#" class="text-white">Refrigerators</a></li>
//                         <li class="mb-3"><a href="#" class="text-white">Appliances</a></li>
//                         <li class="mb-3"><a href="#" class="text-white">Food Storage</a></li>
//                     </ul>

//                 </div>
//             </div>
//         </div>
//         <div class="col-md-5 mb-5">
//             <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style="color: var(--primary);">in Touch</span>
//             </h4>
//             <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
//                 <div class="me-2  ">
//                     <i class="bi bi-envelope fs-5" style="color: var(--primary);"></i>
//                 </div>
//                 <div>
//                     <span class="fs-5 text-dark">info@tasha.com</span>
//                 </div>
//             </div>
//             <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
//                 <div class="me-2  ">
//                     <i class="bi bi-telephone fs-5" style="color: var(--primary);"></i>
//                 </div>
//                 <div>
//                     <span class="fs-5 text-dark">0300-0000000</span>
//                 </div>
//             </div>
//             <div>
//                 <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
//                         style="color: var(--primary);">Address</span></h4>
//                 <iframe
//                     src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
//                     width="100%" style="border:0;" allowfullscreen="" loading="lazy"
//                     referrerpolicy="no-referrer-when-downgrade"></iframe>
//             </div>
//             <div>
//                 <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style="color: var(--primary);">Social
//                         Accounts</span></h4>
//                 <div class="d-flex justify-content-around social">
//                     <i class="bi bi-facebook fs-3"></i>
//                     <i class="bi bi-whatsapp fs-3"></i>
//                     <i class="bi bi-instagram fs-3"></i>
//                     <i class="bi bi-twitter fs-3"></i>
//                 </div>
//             </div>

//         </div>
//     </div>
// </div>
// </footer>

    )
}

export default  FOOOter