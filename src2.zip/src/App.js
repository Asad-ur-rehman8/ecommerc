import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
 import React from "react";
import logo from "./black.png"
import log from "./carousel/1.jpg"
import log2 from "./carousel/2.jpg"
import log3 from "./carousel/3.jpg"
import Nofoor from "./carousel/4.jpg"
import Nofive from "./carousel/slider2.webp"
import imaag1 from "./images/banner/1.jpg"
import imaag2 from "./images/banner/2.jpg"
import imaag3 from "./images/banner/3.jpg"
import image2 from "./images/categories/cookware/c_cookin_pan.webp"
import image3 from "./images/categories/cookware/c_cooking_set.jpg"
import image4 from "./images/categories/cookware/c_grill_pan.jpg"
import image5 from "./images/categories/cookware/c_handi.jpg"
import image6 from "./cookware/fff.jpg"
import image7 from "./cookware/ggg.jpg"
import image8 from "./cookware/hh.jpg" 
import image9 from "./cookware/ii.jpg"
import ref1 from "./refrigerator/freezer1.jpg"
import ref2 from "./images/categories/refrigerator/f_freezer.jpg"
import ref3 from "./images/categories/refrigerator/f_refrigerator.jpg"
import ref4 from "./images/categories/refrigerator/f_freezer_black.jpg"
import fstore from "./images/categories/food_storage/fs_spicy_jar.jpeg"
import fstore2 from "./images/categories/food_storage/fs_lunch_box.jpeg"
import fstore3 from "./images/categories/food_storage/fs_storage_bag.jpeg"
import fstore4 from"./images/categories/food_storage/fs_flask.jpeg"
import double from "./images/categories/refrigerator/f_refrigerator_double_door.jpg"
import cook from "./images/categories/cookware/c_cooking_pot.jpg"
import frez from "./images/categories/refrigerator/f_freezer.jpg"
import ap2 from "./chopper.webp"
import ap1 from "./toaster.jpeg"
import ap4 from "./bread.jpeg"
import ap3  from "./eleectric kettle.jpeg"
import prod from "./mask.png"
import white from "./white.png"
import bs from "./vaccoum.jpg"
import chper from "./download.jpeg"
import "./style.css" 
  import Con from "./Contact__us";
import About from "./about";
import Prod from "./product";
import Home from "./Home";

        function App(){
    
       return (           
             <Routes>
          <Route
            path="/" element={<Home    logjpg={logo} log={log} secimg={log2} third={log3} four = { Nofoor} five={Nofive} chopper={chper} pot ={cook} 
              freez ={frez}  vac ={bs} fimage={imaag1} trd={imaag3} ig={imaag2} imc2={image2} mask={prod}  imc3={image3} imc4={image4} fre1={image5}
              fre2={ref2} fre3={ref3} fre4={ref4}   applin1={ap1} applin2={ap2} applin3={ap3} applin4={ap4} imc5={ref1} d={double} imc6={image6} imc7={image7} imc8={image8} imc9={image9}     fdstore={fstore}
               fdstore2={fstore2} fdstore3={fstore3} fdstore4={fstore4}/>} />
         
              <Route path="/product" element={<Prod logjpg={logo} applin1={ap1} logjpg2={white} chopper={chper} applin3={ap3} applin4={ap4}  />}/> 
          <Route
            path="/Contact__us"
            element={<Con logjpg={logo} logjpg2={white} mask={prod}  />}
          />
          <Route path="/about" element={<About logjpg={logo} logjpg2={white} />} />
        </Routes>
      
  );
  };
  export default App;
  
  



  
