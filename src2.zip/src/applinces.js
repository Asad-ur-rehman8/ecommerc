import React from "react"

function Appline (prop){
    const customStyle = {
        color: "var(--primary)"
    }
    return(
        <div class="mb-5 ">
        <div class="heading-bottom-line my-3 d-flex justify-content-between ">
            <h3 class="h3 fw-bold  py-1 m-0 ">Appliances</h3>
            <a href="#"><button class="btn button rounded-5 py-1 px-4 m-0 ">Show all <i
                        class="bi bi-arrow-right-circle"></i></button></a>
        </div>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-4 row-cols-lg-4   ">
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">
                    
                    
                    
                    <img src={prop.applin2}
                    
                    
                    
                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Food Choppers</h5>
                            <p class="card-text mb-1">A food chopper is a compact appliance or manually
                                operated kitchen tool</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">
                    
                    
                    
                    <img src={prop.applin3}
                    
                    
                    
                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Electric kettle</h5>
                            <p class="card-text mb-1">An electric kettle plugs into an outlet and uses
                                electricity to power an integrated heating element</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <span class="bi bi-star"></span> 
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">
                       
                    
                    
                    <img src={prop.applin4}
                    
                    
                    
                    
                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                    </div>
                    <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Bread Maker</h5>
                            <p class="card-text mb-1">Bread makers are kitchen appliances used to make bread.
                            </p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <span class="bi bi-star"></span>
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col mb-4 d-flex justify-content-center  ">
                <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                    <div class="ratio ratio-16x9 h-100 ">
                    
                    
                    <img src={prop.applin1}
                    
                    
                    
                    
                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                            </div>
                            <div class="card-body d-flex flex-column justify-content-between h-100">
                        <div>
                            <h5 class="card-title fw-bold mb-1">Toaster</h5>
                            <p class="card-text mb-1">A toaster is a kitchen appliance for toasting food such as
                                sliced bread, crumpets, and bagels</p>
                        </div>
                        <div>
                            <div class="rating fs-6 ">
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star-fill"></span>
                                <span class="bi bi-star"></span>
                            </div>
                            <div class="price d-flex justify-content-end fs-4">
                                <span class="bi bi-star"></span>
                                <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
    )
}
export default Appline