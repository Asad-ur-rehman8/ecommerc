import React  from "react";
import { Link} from 'react-router-dom';
function Con(prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    const customStyle2 = {
        border:0
    }
const customstyle3 = {
        border: " 2px solid var(--primary)"
    }

    return(
    <div>
    <nav class="navbar navbar-expand-lg">
    <div class="container-xl">
            <a class="navbar-brand me-lg-5 " href="#">
    
    
            <img src={prop.logjpg} width="100px" alt="logo"/>
    
    
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav gap-lg-4 ">
                    <li class="nav-item">
                        <Link class="nav-link" aria-current="page" to="/">Home</Link>
                    </li>
                    <li class="nav-item">
                        <Link class="nav-link" to="/About">About</Link>
                    </li>
                    <li class="nav-item">
                        <Link class="nav-link" to="/product">Products</Link>
                    </li>
                    <li class="nav-item">
                        <Link class="nav-link active" to="/contact__us">Contact Us</Link>
                    </li>
                </ul>
            </div>
        </div>
    </nav>




    <section class="my-5">
        <div class="container-xl ">
            <div class="d-flex flex-column justify-content-center align-items-md-center mb-5">
                <span class="badge text-start" style={customStyle}>TASHA</span>
                <h3 class="h1">Have Questions? <br class="d-block d-md-none "/> <strong><span
                            style={customStyle}>Contact Us</span></strong>
                </h3>
                <img src={prop.mask} width="120px" alt=""/>         
                </div>         
            <div class="p-5 rounded-5" style={customstyle3}>
              <div class="row">
                    <div class="col-md-6">
              <input type="text" placeholder="Name" class="form-control form-control-lg  mb-3" required/>
                <input type="text" placeholder="Email" class="form-control form-control-lg  mb-3" required/>
                        <input type="text" placeholder="Phone" class="form-control form-control-lg  mb-3" required/>
                        <input type="text" placeholder="Subject" class="form-control form-control-lg  mb-3" required/>
                        <textarea id="formm" class="form-control form-control-lg  mb-3" placeholder="Message"
                            rows="6"></textarea>
                        <button class="mb-3 mb-md-0 btn button w-100 rounded-5 py-2">Submit</button>
                    </div>
                                        <div class="col-md-6">
                        <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style={customStyle}>in
                                Touch</span></h4>
                        <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                            <div class="me-2  ">
                                <i class="bi bi-envelope fs-5" style={customStyle}></i>
                            </div>
                            <div>
                                <span class="fs-5">info@tasha.com</span>
                            </div>
                        </div>
                        <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                            <div class="me-2  ">
                                <i class="bi bi-telephone fs-5" style={customStyle}></i>
                            </div>
                            <div>
                                <span class="fs-5">0300-0000000</span>
                            </div>
                        </div>
                        <div>
                            <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
                                    style={customStyle}>Address</span></h4>
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
                width="100%" style={customStyle2} allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                        <div>
                            <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style={customStyle}>Social
                                    Accounts</span></h4>
                            <div class="d-flex justify-content-around social">
                                <i class="bi bi-facebook fs-3"></i>
                                <i class="bi bi-whatsapp fs-3"></i>
                                <i class="bi bi-instagram fs-3"></i>
                                <i class="bi bi-twitter fs-3"></i>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>


    

    <footer class="bg-dark text-white py-5 rounded-top-5  ">
        <div class="container-xl">
            <div class="row">
                <div class="col-md-2 mb-5">
                <img src={ prop.logjpg2} width="100%" alt=""/>    
                </div>
                <div class="col-md-5 mb-5">
                    <div class="d-flex justify-content-around ">
                        <div>
                            <h3 class="h4" style={customStyle}>Links</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><Link to="/" class="text-white">Home</Link></li>
                                <li class="mb-3"><Link to="/about" class="text-white">About</Link></li>
                                <li class="mb-3"><Link to="/Contact__us" class="text-white active">Contact</Link></li>
                            </ul>
                        </div>
                        <div>
                            <h3 class="h4" style={customStyle}>Categories</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><a href="#" class="text-white">Cookwares</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Refrigerators</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Appliances</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Food Storage</a></li>
                            </ul>
                            </div>
                    </div>
                </div>
                <div class="col-md-5 mb-5">
                    <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style={customStyle}>in Touch</span>
                    </h4>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-envelope fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">info@tasha.com</span>
                        </div>
                    </div>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-telephone fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">0300-0000000</span>
                        </div>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
                                style={customStyle}>Address</span></h4>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
                            width="100%" style={customStyle2} allowfullscreen="" loading="lazy"
                         referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style={customStyle}>Social
                                Accounts</span></h4>
                        <div class="d-flex justify-content-around social">
                            <i class="bi bi-facebook fs-3"></i>
                            <i class="bi bi-whatsapp fs-3"></i>
                            <i class="bi bi-instagram fs-3"></i>
                            <i class="bi bi-twitter fs-3"></i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </footer>
    </div>     


    )
}

export default Con