import React from "react";
import blender from "./Blender.jpeg"
import coffee from "./coffee.jpeg"
import cookin_pan from "./images/categories/cookware/c_cookin_pan.webp"
import cooking_set from "./images/categories/cookware/c_cooking_set.jpg"
import     grill_pan       from "./images/categories/cookware/c_grill_pan.jpg"
import  cooking_pot from "./images/categories/cookware/c_cooking_pot.jpg"
import  frying_pan from "./images/categories/cookware/c_frying_pan.jpg" 
import c_handi from"./images/categories/cookware/c_handi.jpg"
import c_tawa    from "./images/categories/cookware/c_tawa.jpg"
import c_egg_poachers from "./images/categories/cookware/c_egg_poachers.jpg"
import c_steamer from "./images/categories/cookware/c_steamer.jpg"
import fs_spicy_jar from "./images/categories/food_storage/fs_spicy_jar.jpeg"
import lunch_box from "./images/categories/food_storage/fs_lunch_box.jpeg"
import store_bag from "./images/categories/food_storage/fs_storage_bag.jpeg"
import bottle from "./images/categories/food_storage/fs_vaccum_bottles.jpg"
import flask from "./images/categories/food_storage/fs_flask.jpeg" 
import freezer from "./images/categories/refrigerator/f_freezer.jpg" 
import double_door from "./images/categories/refrigerator/f_refrigerator_double_door.jpg"
import black_freez from "./images/categories/refrigerator/f_freezer_black.jpg"
import freez from "./images/categories/refrigerator/f_refrigerator.jpg"
import { Link } from 'react-router-dom';
function Prod(prop) {
    const customStyle = {
        color: "var(--primary)"
    }
    
    const cus2style={
        border: "left 1px solid var(--primary);"
    } 
    const style3 ={
        border:" right 1px solid var(--primary);"
    }
    const customStyle2 = {
        border:0
    }
    const customstyle3 = {
        border: " 2px solid var(--primary)"
    }
    
    
    return(
        <div>
        
        <nav class="navbar navbar-expand-lg">
        <div class="container-xl">
                <a class="navbar-brand me-lg-5 " href="#">
                <img src={prop.logjpg} width="100px" alt="logo"/>
                 </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                    aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav gap-lg-4 ">
                        <li class="nav-item">
                            <Link class="nav-link" aria-current="page" to="/">Home</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/about">About</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link" to="/product">Products</Link>
                        </li>
                        <li class="nav-item">
                            <Link class="nav-link active" to="/Contact__us">Contact Us</Link>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
         <section class="my-5 ">
        <div class="container-xl">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex flex-column justify-content-center align-items-md-center mb-5">
                        <span class="badge text-start" style={customStyle}>TASHA</span>
                        <h3 class="h1"><strong>Kitchen <span style={customStyle}> Appliances</span></strong>
                        </h3>
                   <img src={prop.mask} width="120px" alt=""/>               
             </div>
                </div>
         <div class="col-md-4" style={style3}>           
                    <div class=" bg-white p-3 h-auto w-100 rounded-4">
                        <div class="card-body w-100 ">
                            <div class="heading-bottom-line mb-3 ">
                                <h3 class="h3 fw-bold  py-1 m-0 " style={customStyle}>Categories</h3>
                            </div>
                            <ul class="list-unstyled " id="categoryList">
                                <li class="list-group-item mb-1 "><button class="btn w-100 text-start active"
                                        id="allbtn">All</button>
                                </li>
                                <li class="list-group-item mb-1"><button class="btn w-100 text-start"
                                        id="cookwarebtn">Cookware</button>
                                </li>
                                <li class="list-group-item mb-1 "><button class="btn w-100 text-start"
                                        id="refrigeratorbtn">Refrigerator</button>
                                </li>
                                <li class="list-group-item mb-1 "><button class="btn w-100 text-start"
                                        id="appliancebtn">Appliances</button>
                                </li>
                                <li class="list-group-item mb-1 "><button class="btn w-100 text-start" id="foodbtn">Food
                                        storage</button>
                                </li>
                                 </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-8" style={cus2style}>

                    <div class="heading-bottom-line my-3 ">
                        <h3 class="h3 fw-bold  py-1 m-0" id="categoryHeading">All Products</h3>
                    </div>
                    
                       <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3" id="appliance">
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                <img src={prop.chopper}
                               class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Food Choppers</h5>
                                        <p class="card-text mb-1">A food chopper is a compact appliance or manually
                                            operated kitchen tool</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={prop.applin3}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Electric kettle</h5>
                                        <p class="card-text mb-1">An electric kettle plugs into an outlet and uses
                                            electricity to power an integrated heating element</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={prop.applin4}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Bread Maker</h5>
                                        <p class="card-text mb-1">Bread makers are kitchen appliances used to make
                                            bread.
                                        </p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={blender}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Blender</h5>
                                        <p class="card-text mb-1">A blender is a kitchen and laboratory appliance used
                                            to mix, crush, purée or emulsify food</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={coffee}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Cofee Maker</h5>
                                        <p class="card-text mb-1">A coffee maker is a cooking appliance used tobrew
                                            coffee</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                       <img src={prop.applin1}   
                      class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Toaster</h5>
                                        <p class="card-text mb-1">A toaster is a kitchen appliance for toasting food
                                            such as
                                            sliced bread, crumpets, and bagels</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                         <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3" id="cookware">
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={cookin_pan}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Cooking Pan</h5>
                                        <p class="card-text mb-1">Cooking pans typically have one long handle and are
                                            more
                                            shallow than pots.</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                             <img src={cooking_set}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                  </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Cookware Set</h5>
                                        <p class="card-text mb-1">A kitchen utensil is a small hand held tool used for
                                            food
                                            preparation.</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={grill_pan}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Grill Pen</h5>
                                        <p class="card-text mb-1">A griLL pan is a kind of frying pan with a ribbed
                                            surface
                                            to let the fat drain from food.</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={cooking_pot}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Cooking Pot</h5>
                                        <p class="card-text mb-1">A container of earthenware, metal,etc., usually round
                                            and deep and having a handle</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">


                                    <img src={frying_pan}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Frying Pan</h5>
                                        <p class="card-text mb-1">Frying panis a flat-bottomed or a broad,shallow
                                            container of metal,</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">


                                    <img src={c_handi}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Handi</h5>
                                        <p class="card-text mb-1">A handi is a cooking basic made from copper or clay
                                            (pot).This vessel is deep</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">


                                    <img src={c_tawa}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Tawa</h5>
                                        <p class="card-text mb-1">A griddle is a large, flat cooking surface, and they
                                            are typically square or rectangular in shape,</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                          npm  start          </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">



                                    <img src={c_egg_poachers}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Egg Poachers</h5>
                                        <p class="card-text mb-1">An egg poacher is a piece of cookware meant to
                                            facilitate cooking an egg in a particular way. </p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">


                                    <img src={c_steamer}
                                
                                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Steamer</h5>
                                        <p class="card-text mb-1">A food steamer or steam cooker is a small kitchen
                                            appliance used to cook or prepare various foods with steam heat</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                                   
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3" id="food">
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={fs_spicy_jar}
                                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Spice Jars</h5>
                                        <p class="card-text mb-1">These jars are ideal for storing all your herbs,
                                            spices, tea bags, and lentils.</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={lunch_box}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Lunch Boxes</h5>
                                        <p class="card-text mb-1">For the consumers, stainless steel has been the most
                                            preferred type of lunch box</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                <img src={store_bag}                                        
                                class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Storage Bags</h5>
                                        <p class="card-text mb-1">Similar to LDPE bags, LLDPE bags can be used for
                                            storing food in both refrigerators and freezers</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                 <img src={bottle}                                     
                                    class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Vaccum Bottles</h5>
                                        <p class="card-text mb-1">A vacuum bottle (also known as a Dewar flask, Dewar
                                            bottle or thermos) is an insulating storage vessel</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                                   <img src={flask}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Flask</h5>
                                        <p class="card-text mb-1">Vacuum flasks are used domestically to keep beverages
                                            hot or cold for extended periods</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3" id="refrigerator">
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">                
                                             <img src={freezer}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Freezer</h5>
                                        <p class="card-text mb-1">A freezer is a large container like a fridge in which
                                            the
                                            temperature is kept below freezing point</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                    <img src={freez}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Refrigerator Mini</h5>
                                        <p class="card-text mb-1">A refrigerator is a machine for keeping things cold.It
                                            is
                                            sometimes called an fridge.</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                                <div class="ratio ratio-16x9 h-100 ">
                                  <img src={black_freez}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>                             
                                        </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Freezer Black</h5>
                                        <p class="card-text mb-1">A freezer is a large container like a fridge in which
                                            the
                                            temperature is kept below freezing point</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col mb-4 d-flex justify-content-center  ">
                            <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                           <div class="ratio ratio-16x9 h-100 ">
                           <img src={double_door}
                                        class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                                                  </div>
                                <div class="card-body d-flex flex-column justify-content-between h-100">
                                    <div>
                                        <h5 class="card-title fw-bold mb-1">Refrigerator with double door</h5>
                                        <p class="card-text mb-1">A refrigerator is a machine for keeping things cold.It
                                            is
                                            sometimes called an fridge.</p>
                                    </div>
                                    <div>
                                        <div class="rating fs-6 ">
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star-fill"></span>
                                            <span class="bi bi-star"></span>
                                        </div>
                                        <div class="price d-flex justify-content-end fs-4">
                                            <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="bg-dark text-white py-5 rounded-top-5  ">
        <div class="container-xl">
            <div class="row">
                <div class="col-md-2 mb-5">     
                <img src={ prop.logjpg2} width="100%" alt=""/>
                </div>
                <div class="col-md-5 mb-5">
                    <div class="d-flex justify-content-around ">
                        <div>
                            <h3 class="h4" style={customStyle}>Links</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><Link to="/" class="text-white">Home</Link></li>
                                <li class="mb-3"><Link to="/about" class="text-white">About</Link></li>
                                <li class="mb-3"><Link to="/Contact__us" class="text-white active">Contact</Link></li>
                            </ul>
                        </div>
                        <div>
                            <h3 class="h4" style={customStyle}>Categories</h3>
                            <ul class="list-unstyled">
                                <li class="mb-3"><a href="#" class="text-white">Cookwares</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Refrigerators</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Appliances</a></li>
                                <li class="mb-3"><a href="#" class="text-white">Food Storage</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-5 mb-5">
                    <h4 class="h4 mb-3 py-2 ">Get <span class="fw-bold " style={customStyle}>in Touch</span>
                    </h4>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-envelope fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">info@tasha.com</span>
                        </div>
                    </div>
                    <div class="mb-3 d-flex align-items-center  w-100 px-3 py-2 rounded-3 bg-white">
                        <div class="me-2  ">
                            <i class="bi bi-telephone fs-5" style={customStyle}></i>
                        </div>
                        <div>
                            <span class="fs-5 text-dark">0300-0000000</span>
                        </div>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold "
                                style={customStyle}>Address</span></h4>
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14481.397481575721!2d67.2576629899621!3d24.851914517728364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb3317d179c7ea5%3A0xe7de0f37cad8a69b!2sShah%20Latif%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1692969315408!5m2!1sen!2s"
        
                                    width="100%" style={customStyle2} allowfullscreen="" loading="lazy"
                  referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div>
                        <h4 class="h4 mb-3 py-2 ">Our <span class="fw-bold " style={customStyle}>Social
                                Accounts</span></h4>
                        <div class="d-flex justify-content-around social">
                            <i class="bi bi-facebook fs-3"></i>
                            <i class="bi bi-whatsapp fs-3"></i>
                            <i class="bi bi-instagram fs-3"></i>
                            <i class="bi bi-twitter fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    </div>
    )
}
export default Prod