import React from "react";
function Banner(prop) {
    return(
  <div>
  <section clasNamesName="my-5 ">
  <div className="container-fluid">
            <div className="row">
                <div className="col-12">
                    <div id="banner" className="carousel slide carousel-fade" data-bs-ride="carousel">
                        <div className="carousel-inner">
                            <div className="carousel-item active">
                                <img src={prop.fimage} class="d-block w-100 img-fluid " alt="01"/>
                            </div>
                            <div className="carousel-item">
                                <img src={prop.secimg} class="d-block w-100 img-fluid " alt="02"/>
                            </div>
                            <div className="carousel-item">
                                <img src={prop.trd} class="d-block w-100 img-fluid " alt="03"/>
                            </div>
                        </div>
                        <button className="carousel-control-prev" type="button" data-bs-target="#banner"
                            data-bs-slide="prev">
                            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                        </button>
                        <button className="carousel-control-next" type="button" data-bs-target="#banner"
                            data-bs-slide="next">
                            <span className="carousel-control-next-icon" aria-hidden="true"></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </div>

    )
}
export default Banner