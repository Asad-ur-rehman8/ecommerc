import React from "react"
//import log3 from "./img3.jpg"
function Product(prop){
  const customStyle = {
    color: "var(--primary)"
}
  return(
      
      
      <section>
      <div class="container-xl">
          <div class="d-flex flex-column justify-content-center align-items-start mb-3"></div>
              <span class="badge text-start" style={customStyle}>TASHA</span>
              <h3 class="h1"><strong>Our <span style={customStyle}>Featured Products</span></strong>
              </h3>
              
              
              <img src={prop.mask} width="120px" alt=""/>
          
          
              </div>
          <div class="row row-cols-1 row-cols-sm-2">
              <div class="col mb-4 d-flex justify-content-center  ">
                  <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                      <div class="row g-0 h-100">
                          <div class="col-md-6">
                              <div class="ratio ratio-4x3 h-100 ">
          
          
                             <img src={prop.chopper}
          
          
                              class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="card-body d-flex flex-column justify-content-between h-100">
                                  <div>
                                      <h5 class="card-title fw-bold mb-1">Food Choppers</h5>
                                      <p class="card-text mb-1">A food chopper is a compact appliance or manually
                                          operated kitchen tool</p>
                                  </div>
                                  <div>
                                      <div class="rating fs-6 ">
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star"></span>
                                      </div>
                                      <div class="price d-flex justify-content-end fs-4">
                                          <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col mb-4 d-flex justify-content-center ">
                  <div class="card rounded-4 overflow-hidden shadow h-100 w-100 ">
                      <div class="row g-0 h-100">
                          <div class="col-md-6">
                              <div class="ratio ratio-4x3 h-100 ">
          
          
          
                              <img src={prop.pot}       
          
          
          
                              class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="card-body d-flex flex-column justify-content-between h-100">
                                  <div>
                                      <h5 class="card-title fw-bold mb-1">Cooking Pot</h5>
                                      <p class="card-text mb-1">A container of earthenware, metal,etc., </p>
                                  </div>
                                  <div>
                                      <div class="rating fs-6 ">
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star"></span>
                                      </div>
                                      <div class="price d-flex justify-content-end fs-4">
                                          <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col mb-4 d-flex justify-content-center ">
                  <div class="card rounded-4 overflow-hidden shadow h-100">
                      <div class="row g-0 h-100 w-100 ">
                          <div class="col-md-6">
                              <div class="ratio ratio-4x3 h-100 ">
                          
                          
                          
                          
                              <img src={prop.freez}
          


                                  
                                  class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>

                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="card-body d-flex flex-column justify-content-between h-100">
                                  <div>

                                      <h5 class="card-title fw-bold mb-1">Freezer</h5>
                                      <p class="card-text mb-1">A freezer is a large container like a fridge in which
                                          the temperature is kept below </p>
                                  </div>
                                  <div>
                                      <div class="rating fs-6 ">
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star"></span>
                                      </div>
                                      <div class="price d-flex justify-content-end fs-4">
                                          <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                      </div>

                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col mb-4 d-flex justify-content-center ">
                  <div class="card rounded-4 overflow-hidden shadow h-100">
                      <div class="row g-0 h-100 w-100 ">
                          <div class="col-md-6">
                              <div class="ratio ratio-4x3 h-100 ">
                          
                          
                          
                          
                              <img src={prop.vac}
                          
                          
                          
                          
                              class="img-fluid h-100 object-fit-cover rounded-start" alt="..."/>

                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="card-body d-flex flex-column justify-content-between h-100">
                                  <div>

                                      <h5 class="card-title fw-bold mb-1">Vacuum Bottles</h5>
                                      <p class="card-text mb-1">A vacuum bottle (also known as a Dewar flask, Dewar
                                          bottle or
                                          thermos) is an insulating storage vessel </p>
                                  </div>
                                  <div>
                                      <div class="rating fs-6 ">
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star-fill"></span>
                                          <span class="bi bi-star"></span>
                                      </div>
                                      <div class="price d-flex justify-content-end fs-4">
                                          <p class="fw-bold m-0" style={customStyle}>Rs: 2400</p>
                                      </div>

                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
  
  </section>

      

)
}
export default Product 